const courseList = [
    {
        id:1,
        courseName:"IELTS",
        courseImg: "images/course/ielts.png"
    },
    {
        id:2,
        courseName:"PTE",
        courseImg: "images/course/pte.png"
    },
    // {
    //     id:3,
    //     courseName:"Computer & IT",
    //     courseImg: "images/course/Computer.png"
    // },
    // {
    //     id:4,
    //     courseName:"Korean Language",
    //     courseImg: "images/course/health.png"
    // },
    // {
    //     id:5,
    //     courseName:"Hospitality",
    //     courseImg: "images/course/Hospitality.png"
    // },
    // {
    //     id:6,
    //     courseName:"Nursing",
    //     courseImg: "images/course/Nursing.png"
    // },
    // {
    //     id:7,
    //     courseName:"Law & Legal Studies",
    //     courseImg: "images/course/law.png"
    // },
    // {
    //     id:8,
    //     courseName:"Science and Engineering",
    //     courseImg: "images/course/science.png"
    // },
]

export default courseList;