const countryList = [
    {
        id: 1,
        country_name: "Australia",
        country_img: "images/country/australia.jpg",
    },
    {
        id: 2,
        country_name: "Canada",
        country_img: "images/country/canada.jpg",
    },
    {
        id: 3,
        country_name: "United Kingdom",
        country_img: "images/country/uk.jpg",
    },
    {
        id: 4,
        country_name: "United States",
        country_img: "images/country/us.jpg",
    },
    {
        id: 5,
        country_name: "Natherlands",
        country_img: "images/country/natherlands.jpg",
    },
    {
        id: 6,
        country_name: "New Zealand",
        country_img: "images/country/newzealand.jpg",
    },
]

export default countryList;