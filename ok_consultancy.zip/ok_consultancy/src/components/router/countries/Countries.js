import React from "react";
import CountryUI from "../country/CountryUI";

const Countries = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-lg-3">
          <h1>Australia</h1>
        </div>
        <div className="col-lg-9">
          <h1 className="tc">About Australia</h1>
        </div>
      </div>
      <div className="row">
        <CountryUI />
      </div>
    </div>
  );
};

export default Countries;
