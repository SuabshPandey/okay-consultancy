const imageList = [
    {
        id: 1,
        imgSrc: "images/carosel/image1.jpg",
    },
    {
        id: 2,
        imgSrc: "images/carosel/image1.jpg",
    },
    {
        id: 3,
        imgSrc: "images/carosel/image1.jpg",
    },
    {
        id: 4,
        imgSrc: "images/carosel/image1.jpg",
    },
]

export default imageList;