import React from 'react'

const FooterUI = () => {
    return (
        <div>
            This is the footer.
        </div>
    )
}

export default FooterUI
