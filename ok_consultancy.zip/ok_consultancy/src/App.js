import React from "react";
import Header from "./components/Header/Header";
import HomeRouter from "./components/router/HomeRouter";
import "./App.css";
import Footer from "./components/Footer/Footer";
function App() {
  return (
    <div className="App">
      <Header />
      <HomeRouter />
      <div className="container-fluid footer_bg">
        <hr className="ma_tb" />
        <Footer />
      </div>
    </div>
  );
}

export default App;
